public class Main {
    public static void main(String[] args) {
        
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);
        Employee emp1 = new Employee("E001", "Alice", "Manager", 75000);
        Employee emp2 = new Employee("E002", "Bob", "Developer", 55000);
        Employee emp3 = new Employee("E003", "Charlie", "Designer", 50000);
        Employee emp4 = new Employee("E004", "David", "QA Engineer", 45000);
        Employee emp5 = new Employee("E005", "Eve", "HR", 60000);

       
        ems.addEmployee(emp1);
        ems.addEmployee(emp2);
        ems.addEmployee(emp3);
        ems.addEmployee(emp4);
        ems.addEmployee(emp5);

       
        System.out.println("All Employees:");
        ems.traverseEmployees();

        System.out.println("\nSearching for Employee ID 'E003':");
        Employee searchResult = ems.searchEmployee("E003");
        if (searchResult != null) {
            System.out.println("Employee Found: " + searchResult);
        } else {
            System.out.println("Employee with ID 'E003' not found.");
        }

        
        System.out.println("\nDeleting Employee ID 'E002':");
        boolean deleteResult = ems.deleteEmployee("E002");
        if (deleteResult) {
            System.out.println("Employee with ID 'E002' deleted successfully.");
        } else {
            System.out.println("Employee with ID 'E002' not found.");
        }

       
        System.out.println("\nEmployees after deletion:");
        ems.traverseEmployees();
    }
}
