public class Main {
    public static void main(String[] args) {
        
        Product[] products = {
            new Product("P001", "Laptop", "Electronics"),
            new Product("P002", "Smartphone", "Electronics"),
            new Product("P003", "Tablet", "Electronics"),
            new Product("P004", "Headphones", "Accessories"),
            new Product("P005", "Smartwatch", "Wearables")
        };

        
        System.out.println("Linear Search:");
        String targetName = "Smartwatch";
        Product result = LinearSearch.linearSearch(products, targetName);
        if (result != null) {
            System.out.println("Product found: " + result);
        } else {
            System.out.println("Product not found: " + targetName);
        }

        
        BinarySearch.sortProductsByName(products);

      
        System.out.println("\nBinary Search:");
        targetName = "Tablet";
        result = BinarySearch.binarySearch(products, targetName);
        if (result != null) {
            System.out.println("Product found: " + result);
        } else {
            System.out.println("Product not found: " + targetName);
        }

        System.out.println("\nLinear Search for non-existent product:");
        targetName = "Camera";
        result = LinearSearch.linearSearch(products, targetName);
        if (result != null) {
            System.out.println("Product found: " + result);
        } else {
            System.out.println("Product not found: " + targetName);
        }
        
        System.out.println("\nBinary Search for non-existent product:");
        targetName = "Camera";
        result = BinarySearch.binarySearch(products, targetName);
        if (result != null) {
            System.out.println("Product found: " + result);
        } else {
            System.out.println("Product not found: " + targetName);
        }
    }
}
